<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class blood_donner extends Model
{
    //
}
